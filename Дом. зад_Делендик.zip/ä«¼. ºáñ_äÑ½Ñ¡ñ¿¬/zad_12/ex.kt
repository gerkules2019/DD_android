package zad_12

import java.util.*

fun main() {
    println("Enter num \"N\" factorial : ")
    val input = Scanner(System.`in`)
    val n = input.nextInt()
    var i: Int = 1
    var result: Int = 1

    while(i <= n) {
        result *= i
        i++
    }
    println("Factorial = $result")
}