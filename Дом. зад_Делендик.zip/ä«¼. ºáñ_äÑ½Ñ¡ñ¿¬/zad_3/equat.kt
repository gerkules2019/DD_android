package task_01_03

class Equation {

     fun Divide(word: CharArray?, abc: CharArray?): Int {

        var lenght = 0
         if (word != null) {
             for (i in 0 until word.size) {
                 if (abc != null) {
                     for (j in 0 until abc.size) {
                         if (abc?.get(i) == word?.get(j)) {
                             lenght += i
                         }
                     }
                 }
             }
         }
        return lenght
    }

    fun PrintResult(result: Int) {
        if (result == 0) {
            println("Error. Try agagin")
        }
        println("Result = $result")
    }

     fun Operation(lenghtOne: Int, lenghtTwo: Int, sign: String?) {
        if (sign.equals("+")) {
            var sum: Int = lenghtOne + lenghtTwo
            PrintResult(sum)
            return
        }
        if (sign.equals("-")) {
            var dif: Int = lenghtOne - lenghtTwo
            PrintResult(dif)
            return
        }
        if (sign.equals("*")) {
            var mul: Int = lenghtOne * lenghtTwo
            PrintResult(mul)
            return
        }
        if (sign.equals("/")) {
            var div: Int = lenghtOne / lenghtTwo
            PrintResult(div)
            return
        } else {
            val err: Int = 0
            PrintResult(err)
            return
        }
    }
}