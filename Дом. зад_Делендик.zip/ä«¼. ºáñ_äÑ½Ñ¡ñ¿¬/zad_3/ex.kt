
package zad_3

fun main() {

        val abc: CharArray = Alphabet().CreateAlphabetArray()
        println("Enter data: ")

        val answer = readLine()

        val strArr: Array<String>? = answer?.split("")?.toTypedArray()

        val operandOne = strArr?.get(0)
        val sign = strArr?.get(1)
        val operandTwo = strArr?.get(2)

        val operandOneChar= operandOne?.toCharArray()
        val operandTwoChar = operandTwo?.toCharArray()

        val lenghtOne = Equation().Divide(operandOneChar, abc)
        val lenghtTwo = Equation().Divide(operandTwoChar,abc)

        Equation().Operation(lenghtOne, lenghtTwo, sign)
    }

