package zad_3

class Alphabet {

    fun CreateAlphabetArray(): CharArray {

       var abc: CharArray = CharArray(33)
        var i = 0
        for (letter in 'а'..'е') {
               abc[i] = letter
            i++
            }

	abc[6] = 'ё'

	i = 7
        for (letter in 'ж'..'я') {
               abc[i] = letter
            i++
            }
        return abc
        }
}
