package zad_14

import java.util.*

fun main() {

    println("Enter decimal number : ")
    val input = Scanner(System.`in`)
    val number = input.nextDouble()
    val whole = number.toInt()
    val fraction = number - whole

    println("whole = $whole")
    println("fraction = $fraction")

    var wholeTemp = whole
    var wholeBitString = ""
    while (wholeTemp > 0) {
        var bit = wholeTemp % 2
        wholeTemp /= 2
        wholeBitString += bit.toString()
    }
    print("In binary form = ${wholeBitString.reversed()}")

    var fractionTemp = fraction
    var fractionBitString = ""
    var i = 0

    if (fractionTemp.equals(0.0)) {
        return
    } else {
        while (i < 6) {
            var bit = 0
            fractionTemp *= 2
            if (fractionTemp < 1.0) {
                bit = 0
            }
            if (fractionTemp.equals(1.0)) {
                bit = 1
                fractionBitString += bit.toString()
                break
            } else {
                bit = 1
                fractionTemp -= 1.0
            }
            fractionBitString += bit.toString()
            i++
        }
    }
    print(",${fractionBitString}")
}