package zad_5

	fun main() {
		var sum : Int = 0
		for (i in 0..100) {
			sum += i
		}
		println("Summ (0-100) = $sum")
	}


