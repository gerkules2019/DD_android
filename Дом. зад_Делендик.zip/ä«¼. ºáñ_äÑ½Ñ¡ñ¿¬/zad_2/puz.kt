package zad_2

class Puzzle(val puzzleContent: String, val answer: String) {
}

