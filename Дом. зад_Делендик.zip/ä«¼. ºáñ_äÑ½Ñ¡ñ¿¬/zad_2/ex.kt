/*
* 2)Разработать программу, которая будет задавать вам загадки, а вы должны будете угадать правильный ответ.
* (Скачать можно здесь https://zagadki.info/zag/zhivotnye.html) Настройте программу так, чтобы она распознавала загадки
* и ответ и пользователь мог с ней спокойно взаимодействовать. 
*/

package task_01_02

import kotlin.collections.ArrayList

fun main() {

    val askOne = Puzzle(
	puzzleContent: "Кто на своей голове лес носит?", 
	answer: "олень"
    )
    val askTwo = Puzzle(
	puzzleContent: "У меня живет зверек,\nТолстобрюх и толстощек.", 
	answer: "хомяк"
    )
    val askThree = Puzzle(
	puzzleContent: "Почти как барашек, но без кудряшек.", 
	answer: "коза"
    )
    val askFour = Puzzle(
	puzzleContent: "Мама - лошадь, а папа - осел.\nКакой же ребенок от пары пошел?", 
	answer: "мул"
    )
    val askFive = Puzzle(
	puzzleContent: "Можете тоже проверить вы это - \nЖир у животного зеленого цвета.", 
	answer: "крокодил"
    )

    val puzzleArray = ArrayList<Puzzle>()

    puzzleArray.add(askOne)
    puzzleArray.add(askTwo)
    puzzleArray.add(askThree)
    puzzleArray.add(askFour)
    puzzleArray.add(askFive)

    var exit: Boolean = false

    println("привет! Отгадай загадку:")

    while (!exit) {
        if (puzzleArray.isEmpty()) {
            System.out.println(Answer.EMPTY.answer)
            return
        }
        val rnd = Random()
        val rndNumber = rnd.nextInt(puzzleArray.size)
        val rndNowContent = puzzleArray.get(rndNumber).puzzleContent
        val rndNowAnswer = puzzleArray.get(rndNumber).answer
        puzzleArray.removeAt(rndNumber)
        println("------------------------")
        println(rndNowContent)
        println("------------------------")
        println("Ваш ответ?")

        val answer = readLine()
        answer?.toLowerCase()
        if (answer.equals(rndNowAnswer)) {
            println(Answer.YES.answer)
        } else {
            println(Answer.NO.answer)
        }
        var flag = false

        while (!flag) {
            println(Answer.MAYBE_ELSE.answer)
            val answerElse = readLine()
            answerElse?.toLowerCase()
            if (answerElse.equals("нет")) {
                println("Спасибо! Заходи еще!")
                flag = true
                exit = true
            }
            if (answerElse.equals("да")) {
                println("Удачи!")
                flag = true
            }
        }
    }
}


