package zad_2


enum class Answer(val answer: String) {
    YES("Да"),
    NO("Нет. Увы это неправильный ответ!"),
    MAYBE_ELSE("Отгадаете еще одну загадку?"),
    EMPTY("Загадки, к сожалению, закончились(")
}
