package zad_11

import java.util.*

fun main() {
    var sum: Int = 0

    for (i in 1..99 step 2) {
        sum += i
    }
    /* variant
    for (i in 1..99) {
        if (i % 2 == 0) {
            sum += i
        }
    }
    */
    println("Sum = $sum")
}
