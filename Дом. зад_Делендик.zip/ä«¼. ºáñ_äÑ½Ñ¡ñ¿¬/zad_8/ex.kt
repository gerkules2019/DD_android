package zad_8

import java.util.*

fun main() {
    println("Enter numbers \"a\" and \"b\": ")
    val input = Scanner(System.`in`)
    val a = input.nextInt()
    val b = input.nextInt()
    /* variant
    if (a % 2 == 0) {
        print("\"a\" is even, result (a * b) = ")
        println(a * b)
    } else {
        print("\"a\" is odd, result (a + b) = ")
        println(a + b)
    }
    */
    getWarmth(a, b)
}

fun getWarmth(a: Int, b: Int) = when (a % 2) {
    0 -> {
        print("\"a\" is even, result (a * b) = ")
        println(a * b)
    }
    else -> {
        print("\"a\" is odd, result (a + b) = ")
        println(a + b)
    }
}