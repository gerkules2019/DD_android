package zad_13

class UniverGrade(val sign: Char, var range: IntArray) {
}