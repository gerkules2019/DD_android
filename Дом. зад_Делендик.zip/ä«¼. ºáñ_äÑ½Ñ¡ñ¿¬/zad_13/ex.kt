package zad_13

import java.util.*

fun main() {

    val grade1 = UniverGrade('F', (0..19).toList().toIntArray())
    val grade2 = UniverGrade('E', (20..39).toList().toIntArray())
    val grade3 = UniverGrade('D', (40..59).toList().toIntArray())
    val grade4 = UniverGrade('C', (60..74).toList().toIntArray())
    val grade5 = UniverGrade('B', (75..89).toList().toIntArray())
    val grade6 = UniverGrade('A', (90..100).toList().toIntArray())
    var setGrade = setOf(grade1, grade2, grade3, grade4, grade5, grade6)

    println("Enter mark of the student (range of [0..100]) : ")
    val input = Scanner(System.`in`)
    val mark = input.nextInt()

    if (mark !in 0..100) {
        println("Error entered of mark!")
    } else {
        for (UniverGrade in setGrade) {
            if (UniverGrade.range.contains(mark)) {
                val sign = UniverGrade.sign
                println("Your sign is \"$sign\"")
                return
            }
        }
    }
}