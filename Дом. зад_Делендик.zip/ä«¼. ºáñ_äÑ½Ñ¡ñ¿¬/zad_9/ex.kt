package zad_9

import java.util.*

fun main() {
    println("Enter 3 numbers : ")
    val input = Scanner(System.`in`)
    val a = input.nextDouble()
    val b = input.nextDouble()
    val c = input.nextDouble()

    findMax(a, b, c)
}

fun findMax(a: Double, b: Double, c: Double) {
    val sum = a + b + c
    val mult = a * b * c
    val result = kotlin.math.max(sum, mult)
    if (result == sum) {
        println("Max is addition, result=$result")
    } else {
        println("Max is multiplication, result=$result")
    }

}