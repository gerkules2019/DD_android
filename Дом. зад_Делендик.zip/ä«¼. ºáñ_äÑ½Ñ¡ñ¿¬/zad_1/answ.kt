package zad_1

enum class Answer(val answer: String) {

    YES("Да"),
    NO("Нет"),
    MAYBE_YES("Скорее всего \"Да\""),
    MAYBE_NO("Скорее всего \"Нет\""),
    PERHAPS("Возможно"),
    PROSPECTS("Имеются перспективы"),
    BAD_QUESTION("Вопрос задан неверно")
}