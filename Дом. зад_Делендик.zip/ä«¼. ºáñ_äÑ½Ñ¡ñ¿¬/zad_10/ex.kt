package zad_10

import java.util.*

fun main() {
    println("Enter 2 dim for 1st envelope : ")
    val input = Scanner(System.`in`)
    val a = input.nextInt()
    val b = input.nextInt()
    println("Enter 2 dim for 2st envelope : ")
    val c = input.nextInt()
    val d = input.nextInt()

    isInsert(a, b, c, d)
}

fun isInsert(a: Int, b: Int, c: Int, d: Int) {

    if (a > c) {
        if (b > d) {
            println("It possible")
            return
        }
    }
        if (a > d) {
            if (b > c) {
                println("It possible")
                return
            }
        }
        println("It impossible")
    }
