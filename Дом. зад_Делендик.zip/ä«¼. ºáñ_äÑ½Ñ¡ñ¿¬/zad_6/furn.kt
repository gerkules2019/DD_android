package zad_6

open class Furniture (val height: Int, val color: String, val material: String, val length: Int) {
	}

