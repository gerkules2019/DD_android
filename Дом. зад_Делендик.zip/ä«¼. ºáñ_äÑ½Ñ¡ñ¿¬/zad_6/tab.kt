package zad_6

class Table : Furniture {
	constructor(height: Int, color: String, material: String , length: Int, pegCount: Int) : super(height, color, material, length) {
	val pegCount: Int = 0
	}
}
