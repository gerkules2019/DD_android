package zad_6

class JumpTest (val cat: Cat, val FurnitureUnit: Furniture) {

	fun Print(flag: Boolean, JumpHeight:Int, FurnitureHeight: Int) {
		println("Cat ${cat.name} can jump on $JumpHeight sm")
		println("Furniture has height $FurnitureHeight sm")
		println("Can ${cat.name} jump on furniture?\n $flag")
	}

	fun TestJump() {
		val CalcJumpHeight: Int = cat.CalcHeight()
		val CalcFurnitureHeight: Int = FurnitureUnit.height
		if (CalcJumpHeight >= FurnitureUnit.height) {
			Print(true, CalcJumpHeight, CalcFurnitureHeight)
		} else {
			Print(false, CalcJumpHeight, CalcFurnitureHeight)
		}
	}
}
