package zad_6

class Cat (val name: String, val weigth: Int, val color: String, val height: Int, val length: Int) {

		var power: Int = 0
		init {
			power = (weigth * height * length)
		}

	fun CalcHeight(): Int {
		val g: Double = 9.8
		val time: Double = 1.0  // this is time for jump cat to get top of the table
		val jumpHeight: Int = (((power * time * time) / (2 * weigth * g))).toInt()
		return jumpHeight
	}

}
