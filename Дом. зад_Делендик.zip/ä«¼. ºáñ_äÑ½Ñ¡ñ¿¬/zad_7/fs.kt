
package zad_

	fun main() {
		println("Enter (25-100): ")
		
		val num = readLine()
		val strArr: Array<String>? = num?.split("")?.toTypedArray()
		var result: Int = 0
		
		if (num?.toInt() !in 25..100) {
			println("Bad choose")
		} else {
			strArr?.forEach { ch ->
				result += ch.toInt()
			}
			println("Result = $result")
		}
	}
